DROP TABLE IF EXISTS ordini;

CREATE TABLE ordini (
  id int not null auto_increment,
  nome_utente varchar(50) not null ,
  totale float not null,
  iva int not null,
  quantita int not null,
  nome char(100) not null,
  fatturaNUmero varchar(25) not null,
  buyed varchar(25) not null,
  
  primary key(id),
  FOREIGN KEY (nome_utente) REFERENCES utenti(nome_utente)
);

INSERT INTO ordini values (null,"emmy",42.13,3,1,"Elden Ring","2134","2022-05-03 21:00:00");
INSERT INTO ordini values (null,"emmy",41.11,4,1,"Elden Ring","2135","2022-06-03 21:00:00");
INSERT INTO ordini values (null,"carmine",22.11,7,1,"Elden Ring","2124","2022-05-03 21:00:00");