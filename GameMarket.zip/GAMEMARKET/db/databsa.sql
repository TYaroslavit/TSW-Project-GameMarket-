DROP DATABASE IF EXISTS gamemarket;
CREATE DATABASE gamemarket;
USE gamemarket;

